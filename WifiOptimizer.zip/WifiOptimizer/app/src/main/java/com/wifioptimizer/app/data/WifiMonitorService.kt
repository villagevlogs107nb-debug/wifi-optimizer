package com.wifioptimizer.app.data

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.wifioptimizer.app.MainActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Android does NOT allow a normal app to monitor Wi-Fi indefinitely with no visible indication
 * to the user — Doze mode and background execution limits will suspend a plain background
 * thread/service within minutes. A foreground service with a persistent notification is the
 * only supported, non-root way to get continuous monitoring. This is exactly what this
 * service does: it is honest about its own existence via the notification, as Android requires.
 */
class WifiMonitorService : Service() {

    private val job = SupervisorJob()
    private val scope = CoroutineScope(job)
    private lateinit var wifiMonitor: WifiMonitor
    private lateinit var qualityTester: NetworkQualityTester
    private var monitorJob: Job? = null

    companion object {
        const val CHANNEL_ID = "wifi_monitor_channel"
        const val NOTIFICATION_ID = 1001
        const val POLL_INTERVAL_MS = 5000L
    }

    override fun onCreate() {
        super.onCreate()
        wifiMonitor = WifiMonitor(this)
        qualityTester = NetworkQualityTester()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification("Monitoring Wi-Fi quality…"))
        startMonitoringLoop()
        return START_STICKY
    }

    private fun startMonitoringLoop() {
        monitorJob?.cancel()
        monitorJob = scope.launch {
            while (true) {
                val sample = wifiMonitor.readCurrentSample()
                if (sample != null) {
                    val text = "${sample.ssid}: ${sample.rssiDbm} dBm, ${sample.linkSpeedMbps} Mbps"
                    updateNotification(text)
                    WifiMonitorRepository.pushSample(sample)
                } else {
                    updateNotification("Not connected to Wi-Fi")
                }
                delay(POLL_INTERVAL_MS)
            }
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Wi-Fi Monitoring",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Ongoing Wi-Fi quality monitoring"
            }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildNotification(text: String): Notification {
        val openAppIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Wi-Fi Optimizer")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        scope.cancel()
    }
}
