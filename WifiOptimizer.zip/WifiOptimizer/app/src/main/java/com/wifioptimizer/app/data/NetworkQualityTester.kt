package com.wifioptimizer.app.data

import com.wifioptimizer.app.model.QualitySample
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.abs

/**
 * Measures REAL latency and packet loss. Two strategies are used, in order:
 *
 * 1. Shell out to the device's built-in `/system/bin/ping` binary. On Android this binary
 *    ships with the `CAP_NET_RAW` capability already granted at the OS level, so a normal,
 *    non-rooted app CAN invoke it and get true ICMP round-trip times. This is the same
 *    mechanism used by most reputable "network tools" apps on the Play Store — it is not
 *    a root trick, it's calling an existing system executable.
 * 2. If the ping binary is missing/blocked on a given ROM (some heavily modified OEM builds
 *    restrict it), fall back to a raw TCP connect-time probe against a known-open port
 *    (e.g. 443 on a public DNS resolver). This is a real network measurement too, just at
 *    a different layer (TCP handshake time instead of ICMP echo) and is what this app uses
 *    as its "loss" signal in that fallback path (connect failure/timeout = "lost").
 */
class NetworkQualityTester(
    private val pingTargets: List<String> = listOf("1.1.1.1", "8.8.8.8"),
    private val tcpFallbackHost: String = "1.1.1.1",
    private val tcpFallbackPort: Int = 443,
) {

    suspend fun runProbe(count: Int = 10, timeoutMsPerProbe: Int = 1000): QualitySample =
        withContext(Dispatchers.IO) {
            val target = pingTargets.first()
            val systemPingResult = tryRunSystemPing(target, count, timeoutMsPerProbe)
            val sample = systemPingResult ?: tryTcpFallback(count, timeoutMsPerProbe)
            sample
        }

    private fun tryRunSystemPing(host: String, count: Int, timeoutMsPerProbe: Int): QualitySample? {
        return try {
            val timeoutSec = maxOf(1, timeoutMsPerProbe / 1000)
            val process = ProcessBuilder(
                "/system/bin/ping", "-c", count.toString(), "-W", timeoutSec.toString(), host
            ).redirectErrorStream(true).start()

            val reader = BufferedReader(InputStreamReader(process.inputStream))
            val output = reader.readText()
            process.waitFor()

            parsePingOutput(output, count)
        } catch (e: Exception) {
            null // binary missing, blocked by SELinux policy, or no permission — fall back
        }
    }

    /**
     * Parses standard BSD/Android `ping` output, e.g.:
     * "64 bytes from 1.1.1.1: icmp_seq=1 ttl=59 time=23.4 ms"
     * and the summary line:
     * "5 packets transmitted, 5 received, 0% packet loss, time 4005ms"
     * "rtt min/avg/max/mdev = 21.9/24.6/31.2/3.4 ms"
     */
    private fun parsePingOutput(output: String, requested: Int): QualitySample {
        val rttRegex = Regex("""time[=<]([\d.]+)\s*ms""")
        val times = rttRegex.findAll(output).map { it.groupValues[1].toDouble() }.toList()

        val lossRegex = Regex("""(\d+)%\s*packet loss""")
        val lossMatch = lossRegex.find(output)
        val transmittedRegex = Regex("""(\d+)\s*packets transmitted""")
        val receivedRegex = Regex("""(\d+)\s*received""")

        val transmitted = transmittedRegex.find(output)?.groupValues?.get(1)?.toIntOrNull() ?: requested
        val received = receivedRegex.find(output)?.groupValues?.get(1)?.toIntOrNull() ?: times.size
        val lossPercent = lossMatch?.groupValues?.get(1)?.toDoubleOrNull()
            ?: if (transmitted > 0) (1.0 - received.toDouble() / transmitted) * 100.0 else 100.0

        val avg = if (times.isNotEmpty()) times.average() else null
        val jitter = if (times.size >= 2) {
            times.zipWithNext { a, b -> abs(b - a) }.average()
        } else null

        return QualitySample(
            timestampMs = System.currentTimeMillis(),
            avgLatencyMs = avg,
            jitterMs = jitter,
            packetLossPercent = lossPercent,
            probesSent = transmitted,
            probesReceived = received,
        )
    }

    /** TCP-connect-time fallback: not true ICMP RTT, but a genuine, honestly-labeled measurement. */
    private fun tryTcpFallback(count: Int, timeoutMsPerProbe: Int): QualitySample {
        val times = mutableListOf<Double>()
        var received = 0
        repeat(count) {
            val start = System.nanoTime()
            try {
                Socket().use { socket ->
                    socket.connect(InetSocketAddress(tcpFallbackHost, tcpFallbackPort), timeoutMsPerProbe)
                }
                val elapsedMs = (System.nanoTime() - start) / 1_000_000.0
                times.add(elapsedMs)
                received++
            } catch (e: Exception) {
                // counted as a lost probe
            }
        }
        val avg = if (times.isNotEmpty()) times.average() else null
        val jitter = if (times.size >= 2) times.zipWithNext { a, b -> abs(b - a) }.average() else null
        val loss = if (count > 0) (1.0 - received.toDouble() / count) * 100.0 else 100.0

        return QualitySample(
            timestampMs = System.currentTimeMillis(),
            avgLatencyMs = avg,
            jitterMs = jitter,
            packetLossPercent = loss,
            probesSent = count,
            probesReceived = received,
        )
    }
}
