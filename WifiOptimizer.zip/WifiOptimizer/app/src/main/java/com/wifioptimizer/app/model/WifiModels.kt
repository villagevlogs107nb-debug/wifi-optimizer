package com.wifioptimizer.app.model

/** Which band the current connection is using. */
enum class Band { GHZ_2_4, GHZ_5, GHZ_6, UNKNOWN }

/** A single point-in-time reading of the active Wi-Fi connection. */
data class WifiSample(
    val timestampMs: Long,
    val ssid: String,
    val bssid: String,
    val rssiDbm: Int,          // e.g. -55 (closer to 0 is stronger)
    val linkSpeedMbps: Int,    // TX link speed reported by the radio
    val rxLinkSpeedMbps: Int,
    val frequencyMhz: Int,
    val channelWidthMhz: Int,
    val band: Band,
    val standard: String,      // e.g. "802.11ac", "802.11ax" (best-effort, API dependent)
)

/** Result of an active network-quality probe (ping + loss), separate from radio-layer stats. */
data class QualitySample(
    val timestampMs: Long,
    val avgLatencyMs: Double?,   // null if all probes failed
    val jitterMs: Double?,
    val packetLossPercent: Double,
    val probesSent: Int,
    val probesReceived: Int,
)

/** A nearby access point seen in a scan, used for AP/channel recommendations. */
data class ScannedAp(
    val ssid: String,
    val bssid: String,
    val rssiDbm: Int,
    val frequencyMhz: Int,
    val channel: Int,
    val band: Band,
    val isSameNetwork: Boolean, // same SSID as the one the phone is configured for
)

/** Overall computed quality score + human-readable recommendations. */
data class QualityVerdict(
    val score: Int,               // 0-100
    val label: String,            // "Excellent", "Good", "Weak", "Poor"
    val recommendations: List<String>,
    val suggestedBand: Band?,     // which band the app thinks is better right now
    val tooFarFromRouter: Boolean,
)

fun frequencyToBand(freqMhz: Int): Band = when (freqMhz) {
    in 2400..2500 -> Band.GHZ_2_4
    in 4900..5900 -> Band.GHZ_5
    in 5925..7125 -> Band.GHZ_6
    else -> Band.UNKNOWN
}

fun frequencyToChannel(freqMhz: Int): Int = when {
    freqMhz == 2484 -> 14
    freqMhz in 2412..2472 -> (freqMhz - 2407) / 5
    freqMhz in 5000..5900 -> (freqMhz - 5000) / 5
    freqMhz in 5925..7125 -> (freqMhz - 5950) / 5 + 1
    else -> -1
}
