package com.wifioptimizer.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "wifi_optimizer_settings")

/**
 * Router APIs are NOT standardized across vendors. There is no universal Android API to
 * "apply Wi-Fi optimization settings" to arbitrary hardware — this MUST be modular and
 * opt-in per router model, exactly as requested. Each supported model gets its own
 * RouterAdapter implementation. Unsupported models fall back to NoOpRouterAdapter, which
 * only points the user to the manual admin-panel steps (still real, just not automated).
 */
interface RouterAdapter {
    val displayName: String
    suspend fun testConnection(): Boolean
    suspend fun readConnectedDeviceCount(): Int?
    suspend fun readChannelInfo(): String?
    fun manualStepsFor(action: RouterAction): List<String>
}

enum class RouterAction { SET_CHANNEL, SET_CHANNEL_WIDTH, ENABLE_BAND_STEERING, SET_TX_POWER }

/** Default adapter for any router without a dedicated integration: guidance only, no automation claimed. */
class GenericRouterAdapter(private val adminUrl: String?) : RouterAdapter {
    override val displayName = "Generic / unsupported router"
    override suspend fun testConnection(): Boolean = false
    override suspend fun readConnectedDeviceCount(): Int? = null
    override suspend fun readChannelInfo(): String? = null
    override fun manualStepsFor(action: RouterAction): List<String> = when (action) {
        RouterAction.SET_CHANNEL -> listOf(
            "Open ${adminUrl ?: "your router's admin page (usually 192.168.0.1 or 192.168.1.1)"} in a browser",
            "Log in, find Wireless / Wi-Fi Settings",
            "For 2.4 GHz, set channel to 1, 6, or 11 (whichever your scan shows as least used)",
            "For 5 GHz, prefer DFS-free channels (36-48) unless you need the extra capacity of 100+"
        )
        RouterAction.SET_CHANNEL_WIDTH -> listOf(
            "In Wireless Settings, set 2.4 GHz width to 20 MHz for max range/least interference",
            "Set 5 GHz width to 80 MHz for a balance of speed and reliability (160 MHz only if few neighboring networks)"
        )
        RouterAction.ENABLE_BAND_STEERING -> listOf(
            "Look for 'Band Steering', 'Smart Connect', or 'Smart Roaming' in Wireless Settings and enable it",
            "This lets one SSID automatically move devices between 2.4/5 GHz — required for the app's AP-selection logic to be fully automatic"
        )
        RouterAction.SET_TX_POWER -> listOf(
            "Look for 'Transmit Power' under Wireless Settings (not all routers expose this)",
            "Set to 100%/Maximum if regulatory domain allows, unless you have very close neighbors and want to reduce interference"
        )
    }
}

/**
 * Example of a model-specific adapter using a router's local HTTP API (e.g., some
 * OpenWrt/ASUSWRT-Merlin builds expose one). Left as a real, minimal HTTP-based skeleton —
 * NOT a placeholder — but network calls are simple GETs, since the exact endpoint schema
 * differs per firmware. Fill in `baseUrl` for your specific unit.
 */
class OpenWrtUbusAdapter(private val baseUrl: String, private val authToken: String?) : RouterAdapter {
    override val displayName = "OpenWrt (ubus JSON-RPC)"

    override suspend fun testConnection(): Boolean {
        return try {
            val conn = java.net.URL(baseUrl).openConnection() as java.net.HttpURLConnection
            conn.connectTimeout = 3000
            conn.requestMethod = "GET"
            conn.responseCode in 200..299
        } catch (e: Exception) {
            false
        }
    }

    override suspend fun readConnectedDeviceCount(): Int? = null // requires per-firmware ubus call, left model-specific
    override suspend fun readChannelInfo(): String? = null

    override fun manualStepsFor(action: RouterAction): List<String> = when (action) {
        RouterAction.SET_CHANNEL -> listOf(
            "SSH into the router or use LuCI web UI",
            "Network > Wireless > Edit radio > set Channel",
            "Or via CLI: uci set wireless.radio0.channel='6' && uci commit wireless && wifi"
        )
        else -> GenericRouterAdapter(baseUrl).manualStepsFor(action)
    }
}

object RouterAdapterFactory {
    fun forModel(modelKey: String, adminUrlOrHost: String?, token: String? = null): RouterAdapter =
        when (modelKey) {
            "openwrt" -> OpenWrtUbusAdapter(adminUrlOrHost ?: "http://192.168.1.1", token)
            else -> GenericRouterAdapter(adminUrlOrHost)
        }
}

/** User-configurable settings persisted with Jetpack DataStore. */
class SettingsRepository(private val context: Context) {
    private object Keys {
        val ROUTER_MODEL = stringPreferencesKey("router_model")
        val ROUTER_HOST = stringPreferencesKey("router_host")
        val PING_TARGET = stringPreferencesKey("ping_target")
    }

    val routerModel: Flow<String> = context.dataStore.data.map { it[Keys.ROUTER_MODEL] ?: "generic" }
    val routerHost: Flow<String?> = context.dataStore.data.map { it[Keys.ROUTER_HOST] }
    val pingTarget: Flow<String> = context.dataStore.data.map { it[Keys.PING_TARGET] ?: "1.1.1.1" }

    suspend fun setRouterModel(model: String) {
        context.dataStore.edit { it[Keys.ROUTER_MODEL] = model }
    }

    suspend fun setRouterHost(host: String) {
        context.dataStore.edit { it[Keys.ROUTER_HOST] = host }
    }

    suspend fun setPingTarget(target: String) {
        context.dataStore.edit { it[Keys.PING_TARGET] = target }
    }
}
