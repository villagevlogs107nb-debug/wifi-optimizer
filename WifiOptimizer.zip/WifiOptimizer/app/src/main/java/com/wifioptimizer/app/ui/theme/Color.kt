package com.wifioptimizer.app.ui.theme

import androidx.compose.ui.graphics.Color

val Excellent = Color(0xFF2ECC71)
val Good = Color(0xFF58D68D)
val Weak = Color(0xFFF39C12)
val Poor = Color(0xFFE74C3C)

val Primary = Color(0xFF3B82F6)
val Background = Color(0xFF0F1115)
val Surface = Color(0xFF1A1D24)
val OnSurface = Color(0xFFE6E8EB)
val OnSurfaceMuted = Color(0xFF9AA0AC)
