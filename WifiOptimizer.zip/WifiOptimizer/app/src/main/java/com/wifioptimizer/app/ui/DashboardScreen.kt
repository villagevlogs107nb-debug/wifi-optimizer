package com.wifioptimizer.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wifioptimizer.app.model.Band
import com.wifioptimizer.app.model.QualityVerdict
import com.wifioptimizer.app.model.WifiSample
import com.wifioptimizer.app.ui.theme.Excellent
import com.wifioptimizer.app.ui.theme.Good
import com.wifioptimizer.app.ui.theme.OnSurfaceMuted
import com.wifioptimizer.app.ui.theme.Poor
import com.wifioptimizer.app.ui.theme.Weak
import com.wifioptimizer.app.viewmodel.WifiViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(viewModel: WifiViewModel, onOpenSettings: () -> Unit) {
    val state by viewModel.uiState.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Wi-Fi Optimizer") },
                actions = {
                    IconButton(onClick = { viewModel.refreshScan() }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Rescan")
                    }
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            item { ScoreCard(state.verdict) }
            item { ConnectionCard(state.currentSample) }
            item {
                QualityTestCard(
                    latencyMs = state.quality?.avgLatencyMs,
                    jitterMs = state.quality?.jitterMs,
                    lossPercent = state.quality?.packetLossPercent,
                    isRunning = state.isRunningQualityTest,
                    onRunTest = { viewModel.runQualityTestNow() },
                )
            }
            item { RecommendationsCard(state.verdict) }
            item { NearbyApsHeader(count = state.nearbyAps.size) }
            items(state.nearbyAps) { ap ->
                NearbyApRow(ssid = ap.ssid, rssi = ap.rssiDbm, band = ap.band, isSameNetwork = ap.isSameNetwork)
            }
        }
    }
}

@Composable
private fun ScoreCard(verdict: QualityVerdict) {
    val color = when (verdict.label) {
        "Excellent" -> Excellent
        "Good" -> Good
        "Weak" -> Weak
        else -> Poor
    }
    Card(shape = RoundedCornerShape(20.dp)) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(color.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Text("${verdict.score}", fontSize = 40.sp, fontWeight = FontWeight.Bold, color = color)
            }
            Spacer(Modifier.height(12.dp))
            Text(verdict.label, style = MaterialTheme.typography.titleMedium, color = color)
            if (verdict.tooFarFromRouter) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "Too far from router",
                    style = MaterialTheme.typography.labelSmall,
                    color = Poor
                )
            }
        }
    }
}

@Composable
private fun ConnectionCard(sample: WifiSample?) {
    Card(shape = RoundedCornerShape(20.dp)) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (sample != null) Icons.Default.Wifi else Icons.Default.WifiOff,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
                Spacer(Modifier.width(8.dp))
                Text(sample?.ssid ?: "Not connected", style = MaterialTheme.typography.titleMedium)
            }
            Spacer(Modifier.height(16.dp))
            if (sample != null) {
                MetricRow("Signal", "${sample.rssiDbm} dBm")
                MetricRow("Link speed (TX)", "${sample.linkSpeedMbps} Mbps")
                MetricRow("Link speed (RX)", "${sample.rxLinkSpeedMbps} Mbps")
                MetricRow("Frequency", "${sample.frequencyMhz} MHz")
                MetricRow("Band", bandLabel(sample.band))
                MetricRow("Channel width", if (sample.channelWidthMhz > 0) "${sample.channelWidthMhz} MHz" else "unknown")
                MetricRow("Standard", sample.standard)
            } else {
                Text("Connect to a Wi-Fi network to see live metrics.", color = OnSurfaceMuted)
            }
        }
    }
}

@Composable
private fun QualityTestCard(
    latencyMs: Double?,
    jitterMs: Double?,
    lossPercent: Double?,
    isRunning: Boolean,
    onRunTest: () -> Unit,
) {
    Card(shape = RoundedCornerShape(20.dp)) {
        Column(modifier = Modifier.padding(20.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Network quality test", style = MaterialTheme.typography.titleMedium)
                Button(onClick = onRunTest, enabled = !isRunning) {
                    Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (isRunning) "Testing…" else "Run test")
                }
            }
            Spacer(Modifier.height(16.dp))
            MetricRow("Avg latency", latencyMs?.let { "%.1f ms".format(it) } ?: "—")
            MetricRow("Jitter", jitterMs?.let { "%.1f ms".format(it) } ?: "—")
            MetricRow("Packet loss", lossPercent?.let { "%.0f%%".format(it) } ?: "—")
        }
    }
}

@Composable
private fun RecommendationsCard(verdict: QualityVerdict) {
    Card(shape = RoundedCornerShape(20.dp)) {
        Column(modifier = Modifier.padding(20.dp)) {
            Text("Recommendations", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(12.dp))
            verdict.recommendations.forEach { rec ->
                Row(modifier = Modifier.padding(bottom = 10.dp)) {
                    Text("•  ", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    Text(rec, style = MaterialTheme.typography.bodyMedium)
                }
            }
            verdict.suggestedBand?.let {
                Spacer(Modifier.height(4.dp))
                AssistChip(onClick = {}, label = { Text("Suggested band: ${bandLabel(it)}") })
            }
        }
    }
}

@Composable
private fun NearbyApsHeader(count: Int) {
    Text(
        "Nearby access points ($count)",
        style = MaterialTheme.typography.titleMedium,
        modifier = Modifier.padding(top = 4.dp)
    )
}

@Composable
private fun NearbyApRow(ssid: String, rssi: Int, band: Band, isSameNetwork: Boolean) {
    Card(shape = RoundedCornerShape(14.dp)) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(ssid.ifBlank { "<hidden>" }, fontWeight = FontWeight.Medium)
                Text(bandLabel(band), style = MaterialTheme.typography.labelSmall, color = OnSurfaceMuted)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (isSameNetwork) {
                    AssistChip(onClick = {}, label = { Text("Your network") })
                    Spacer(Modifier.width(8.dp))
                }
                Text("$rssi dBm")
            }
        }
    }
}

@Composable
private fun MetricRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(label, color = OnSurfaceMuted)
        Text(value, fontWeight = FontWeight.Medium)
    }
}

private fun bandLabel(band: Band): String = when (band) {
    Band.GHZ_2_4 -> "2.4 GHz"
    Band.GHZ_5 -> "5 GHz"
    Band.GHZ_6 -> "6 GHz"
    Band.UNKNOWN -> "Unknown"
}
