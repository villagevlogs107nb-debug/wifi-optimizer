package com.wifioptimizer.app.data

import com.wifioptimizer.app.model.WifiSample
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Process-wide holder so the foreground service (which may keep running after the Activity
 * is destroyed/recreated) and the Compose UI observe the same, single source of truth.
 * Deliberately simple (no DI framework) to keep the project easy to read and compile.
 */
object WifiMonitorRepository {
    private const val HISTORY_LIMIT = 60 // ~5 minutes at 5s polling

    private val _latestSample = MutableStateFlow<WifiSample?>(null)
    val latestSample: StateFlow<WifiSample?> = _latestSample.asStateFlow()

    private val _rssiHistory = MutableStateFlow<List<Int>>(emptyList())
    val rssiHistory: StateFlow<List<Int>> = _rssiHistory.asStateFlow()

    fun pushSample(sample: WifiSample) {
        _latestSample.value = sample
        _rssiHistory.value = (_rssiHistory.value + sample.rssiDbm).takeLast(HISTORY_LIMIT)
    }
}
