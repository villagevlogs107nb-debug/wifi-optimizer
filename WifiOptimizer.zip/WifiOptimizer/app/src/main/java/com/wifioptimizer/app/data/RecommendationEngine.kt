package com.wifioptimizer.app.data

import com.wifioptimizer.app.model.Band
import com.wifioptimizer.app.model.QualitySample
import com.wifioptimizer.app.model.QualityVerdict
import com.wifioptimizer.app.model.ScannedAp
import com.wifioptimizer.app.model.WifiSample
import kotlin.math.roundToInt

/**
 * Pure, deterministic scoring logic — no network calls, no magic. Every recommendation here maps
 * to a real, physically meaningful cause (distance/obstruction, congestion, band choice,
 * interference), never to "tap this button to boost signal."
 */
object RecommendationEngine {

    fun evaluate(
        wifi: WifiSample?,
        quality: QualitySample?,
        nearbyAps: List<ScannedAp>,
        recentRssiHistory: List<Int>,
    ): QualityVerdict {
        if (wifi == null) {
            return QualityVerdict(
                score = 0,
                label = "Disconnected",
                recommendations = listOf(
                    "Phone is not associated with any Wi-Fi network. Check that Wi-Fi is enabled and in range of an access point."
                ),
                suggestedBand = null,
                tooFarFromRouter = true,
            )
        }

        val recs = mutableListOf<String>()

        // --- Signal strength component (0-40 points) ---
        // Rough, widely-used RSSI bands. These are physics, not app opinion:
        // >= -50 dBm excellent, -60 good, -67 usable for video, -70 marginal, <= -80 essentially unusable.
        val rssi = wifi.rssiDbm
        val signalScore = when {
            rssi >= -50 -> 40
            rssi >= -60 -> 34
            rssi >= -67 -> 26
            rssi >= -70 -> 16
            rssi >= -80 -> 8
            else -> 0
        }
        val tooFar = rssi < -75

        if (tooFar) {
            recs.add(
                "Signal is $rssi dBm — you are too far from the access point or too many walls " +
                    "are in the way. Moving closer, removing obstructions, or adding a repeater/mesh " +
                    "node between you and the router is the only real fix; no app setting changes this."
            )
        } else if (rssi < -67) {
            recs.add("Signal is $rssi dBm (marginal). Try moving 3-5 meters closer or into direct line of sight of the router.")
        }

        // --- Stability component (0-20 points), based on RSSI variance over recent history ---
        val stabilityScore: Int
        if (recentRssiHistory.size >= 3) {
            val mean = recentRssiHistory.average()
            val variance = recentRssiHistory.sumOf { (it - mean) * (it - mean) } / recentRssiHistory.size
            val stdDev = kotlin.math.sqrt(variance)
            stabilityScore = when {
                stdDev < 3 -> 20
                stdDev < 6 -> 14
                stdDev < 10 -> 8
                else -> 2
            }
            if (stdDev >= 6) {
                recs.add(
                    "Signal is fluctuating by ~${stdDev.roundToInt()} dB while mostly stationary. This " +
                        "usually means you're moving between rooms/obstructions, or another device on the " +
                        "same channel is causing intermittent interference."
                )
            }
        } else {
            stabilityScore = 10 // not enough history yet — neutral score
        }

        // --- Latency / loss component (0-25 points) ---
        var latencyScore = 12
        if (quality != null) {
            val lat = quality.avgLatencyMs
            latencyScore = when {
                lat == null -> 0
                lat < 20 -> 25
                lat < 50 -> 20
                lat < 100 -> 12
                lat < 200 -> 6
                else -> 2
            }
            if (quality.packetLossPercent > 15) {
                recs.add(
                    "Packet loss is ${quality.packetLossPercent.roundToInt()}%. At this range/band this is " +
                        "usually congestion or interference, not distance alone — check the channel " +
                        "recommendations below."
                )
            }
            if (lat != null && lat > 100) {
                recs.add("Latency is ${lat.roundToInt()} ms, high for a local Wi-Fi hop. Congested channel or router CPU overload are the most common causes.")
            }
        }

        // --- Link speed / band component (0-15 points) ---
        val linkSpeedScore = when {
            wifi.linkSpeedMbps >= 400 -> 15
            wifi.linkSpeedMbps >= 150 -> 12
            wifi.linkSpeedMbps >= 72 -> 8
            wifi.linkSpeedMbps >= 24 -> 4
            else -> 1
        }

        var suggestedBand: Band? = null
        if (wifi.band == Band.GHZ_5 && rssi < -72) {
            suggestedBand = Band.GHZ_2_4
            recs.add(
                "You're on 5 GHz with a weak signal ($rssi dBm). 5 GHz has much shorter range through " +
                    "walls than 2.4 GHz. If your router broadcasts a separate 2.4 GHz SSID, switching to it " +
                    "will very likely give a MORE STABLE (though lower peak speed) connection at this distance."
            )
        } else if (wifi.band == Band.GHZ_2_4 && rssi >= -60) {
            val has5 = nearbyAps.any { it.isSameNetwork && it.band == Band.GHZ_5 }
            if (has5) {
                suggestedBand = Band.GHZ_5
                recs.add(
                    "Signal is strong enough ($rssi dBm) to move to 5 GHz for a real speed increase — " +
                        "your network appears to broadcast a 5 GHz SSID as well."
                )
            }
        }

        // --- Congestion check from scan results ---
        val sameChannelCount = nearbyAps.count {
            !it.isSameNetwork && it.frequencyMhz == wifi.frequencyMhz
        }
        if (sameChannelCount >= 3) {
            recs.add(
                "$sameChannelCount other networks were seen on the same channel (${wifi.frequencyMhz} MHz). " +
                    "This is real co-channel interference. On the router, switch to a less crowded channel " +
                    "(for 2.4 GHz, only channels 1, 6, and 11 don't overlap each other)."
            )
        }

        if (recs.isEmpty()) {
            recs.add("Connection looks healthy. No corrective action needed right now.")
        }

        val total = (signalScore + stabilityScore + latencyScore + linkSpeedScore)
            .coerceIn(0, 100)

        val label = when {
            total >= 85 -> "Excellent"
            total >= 65 -> "Good"
            total >= 40 -> "Weak"
            else -> "Poor"
        }

        return QualityVerdict(
            score = total,
            label = label,
            recommendations = recs,
            suggestedBand = suggestedBand,
            tooFarFromRouter = tooFar,
        )
    }
}
