package com.wifioptimizer.app.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.wifi.WifiInfo
import android.net.wifi.WifiManager
import android.os.Build
import com.wifioptimizer.app.model.Band
import com.wifioptimizer.app.model.ScannedAp
import com.wifioptimizer.app.model.WifiSample
import com.wifioptimizer.app.model.frequencyToBand
import com.wifioptimizer.app.model.frequencyToChannel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.distinctUntilChanged

/**
 * Reads what Android actually exposes about the current Wi-Fi link.
 *
 * IMPORTANT (read this before assuming any number here is something the app can "fix"):
 * - RSSI, link speed, frequency and channel width are reported BY THE RADIO DRIVER.
 *   The app is a read-only observer of these values. It cannot change antenna gain,
 *   transmit power, or true physical range.
 * - On Android 8.1+ (API 27+), `WifiInfo.getRssi()` and related fields are the
 *   supported, documented way to read this. Some OEMs throttle scan frequency to
 *   save battery; the app respects Android's system-level scan throttling rather
 *   than trying to defeat it.
 */
class WifiMonitor(context: Context) {

    private val appContext = context.applicationContext
    private val wifiManager =
        appContext.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
    private val connectivityManager =
        appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager

    /** Emits a fresh [WifiSample] whenever the network capabilities of the active Wi-Fi change. */
    fun observeCurrentConnection() = callbackFlow {
        fun push() {
            readCurrentSample()?.let { trySend(it) }
        }

        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onCapabilitiesChanged(
                network: Network,
                capabilities: NetworkCapabilities
            ) {
                if (capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) push()
            }

            override fun onLost(network: Network) {
                trySend(null as WifiSample? ?: return)
            }
        }

        val request = android.net.NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .build()

        connectivityManager.registerNetworkCallback(request, callback)
        push() // emit an initial value immediately instead of waiting for the first change

        awaitClose { connectivityManager.unregisterNetworkCallback(callback) }
    }.distinctUntilChanged()

    /** One-shot synchronous read of the current connection, used for polling loops. */
    fun readCurrentSample(): WifiSample? {
        val info: WifiInfo = getConnectionInfoCompat() ?: return null
        if (info.networkId == -1) return null // not actually associated to an AP

        val freq = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) info.frequency else -1
        val band = frequencyToBand(freq)
        val width = channelWidthOf(info)

        return WifiSample(
            timestampMs = System.currentTimeMillis(),
            ssid = info.ssid?.trim('"') ?: "<unknown>",
            bssid = info.bssid ?: "<unknown>",
            rssiDbm = info.rssi,
            linkSpeedMbps = info.linkSpeed,
            rxLinkSpeedMbps = if (Build.VERSION.SDK_INT >= 30) info.rxLinkSpeed else info.linkSpeed,
            frequencyMhz = freq,
            channelWidthMhz = width,
            band = band,
            standard = standardNameOf(info),
        )
    }

    private fun getConnectionInfoCompat(): WifiInfo? {
        // WifiManager#getConnectionInfo() is deprecated on API 31+ in favor of reading
        // TransportInfo off the active NetworkCapabilities, but it still works and remains
        // the simplest cross-version path; we fall back to the NetworkCapabilities route
        // when available for more accurate post-Android-12 behavior.
        val active = connectivityManager.activeNetwork
        val caps = active?.let { connectivityManager.getNetworkCapabilities(it) }
        if (caps != null && caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
            val transportInfo = caps.transportInfo
            if (transportInfo is WifiInfo) return transportInfo
        }
        @Suppress("DEPRECATION")
        return wifiManager.connectionInfo
    }

    private fun channelWidthOf(info: WifiInfo): Int {
        if (Build.VERSION.SDK_INT < 23) return -1
        return when (info.channelWidth) {
            WifiInfo.CHANNEL_WIDTH_20MHZ -> 20
            WifiInfo.CHANNEL_WIDTH_40MHZ -> 40
            WifiInfo.CHANNEL_WIDTH_80MHZ -> 80
            WifiInfo.CHANNEL_WIDTH_160MHZ -> 160
            WifiInfo.CHANNEL_WIDTH_80MHZ_PLUS_MHZ -> 80 // 80+80, reported as 80 for simplicity
            else -> -1
        }
    }

    /** Best-effort 802.11 standard label; Android does not expose this directly pre-API 29. */
    private fun standardNameOf(info: WifiInfo): String {
        if (Build.VERSION.SDK_INT < 29) return "unknown (requires API 29+)"
        return when (info.wifiStandard) {
            4 -> "802.11n"
            5 -> "802.11ac"
            6 -> "802.11ax (Wi-Fi 6)"
            7 -> "802.11be (Wi-Fi 7)"
            else -> "unknown"
        }
    }

    /**
     * Triggers a scan and returns nearby APs. Requires ACCESS_FINE_LOCATION on API <33 and
     * NEARBY_WIFI_DEVICES on API 33+, because Android treats Wi-Fi scan results as
     * location-sensitive data. This is a hard Android platform restriction, not a design
     * choice of this app.
     *
     * Also subject to system scan throttling (max ~4 scans per 2 minutes per app in the
     * background on stock Android) — the app cannot bypass this without root.
     */
    @Suppress("DEPRECATION")
    fun startScan(): Boolean = wifiManager.startScan()

    @Suppress("DEPRECATION")
    fun getScanResults(currentSsid: String?): List<ScannedAp> {
        return wifiManager.scanResults.map { r ->
            val band = frequencyToBand(r.frequency)
            ScannedAp(
                ssid = r.SSID,
                bssid = r.BSSID,
                rssiDbm = r.level,
                frequencyMhz = r.frequency,
                channel = frequencyToChannel(r.frequency),
                band = band,
                isSameNetwork = currentSsid != null && r.SSID == currentSsid,
            )
        }.sortedByDescending { it.rssiDbm }
    }

    fun is5GhzSupported(): Boolean =
        if (Build.VERSION.SDK_INT >= 21) wifiManager.is5GHzBandSupported else false

    fun is6GhzSupported(): Boolean =
        if (Build.VERSION.SDK_INT >= 30) wifiManager.is6GHzBandSupported else false
}
