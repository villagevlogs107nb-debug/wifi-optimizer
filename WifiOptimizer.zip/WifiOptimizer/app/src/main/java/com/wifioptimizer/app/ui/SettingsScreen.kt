package com.wifioptimizer.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.wifioptimizer.app.data.SettingsRepository
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(settingsRepository: SettingsRepository, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    val routerModel by settingsRepository.routerModel.collectAsStateWithLifecycleCompat("generic")
    val routerHost by settingsRepository.routerHost.collectAsStateWithLifecycleCompat(null)
    val pingTarget by settingsRepository.pingTarget.collectAsStateWithLifecycleCompat("1.1.1.1")

    var hostField by remember(routerHost) { mutableStateOf(routerHost ?: "") }
    var pingField by remember(pingTarget) { mutableStateOf(pingTarget) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Settings") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(20.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Text("Router integration", style = MaterialTheme.typography.titleMedium)
            Text(
                "Router APIs differ by vendor. Select a profile if your router has a supported " +
                    "integration; otherwise the app gives manual step-by-step instructions instead " +
                    "of pretending to auto-configure hardware it can't reach.",
                style = MaterialTheme.typography.bodyMedium
            )

            var expanded by remember { mutableStateOf(false) }
            ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = it }) {
                OutlinedTextField(
                    value = when (routerModel) {
                        "openwrt" -> "OpenWrt (ubus API)"
                        else -> "Generic (manual steps)"
                    },
                    onValueChange = {},
                    readOnly = true,
                    label = { Text("Router profile") },
                    modifier = Modifier.menuAnchor().fillMaxWidth()
                )
                ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    DropdownMenuItem(
                        text = { Text("Generic (manual steps)") },
                        onClick = {
                            scope.launch { settingsRepository.setRouterModel("generic") }
                            expanded = false
                        }
                    )
                    DropdownMenuItem(
                        text = { Text("OpenWrt (ubus API)") },
                        onClick = {
                            scope.launch { settingsRepository.setRouterModel("openwrt") }
                            expanded = false
                        }
                    )
                }
            }

            OutlinedTextField(
                value = hostField,
                onValueChange = { hostField = it },
                label = { Text("Router admin host / IP") },
                placeholder = { Text("192.168.1.1") },
                modifier = Modifier.fillMaxWidth()
            )

            OutlinedTextField(
                value = pingField,
                onValueChange = { pingField = it },
                label = { Text("Ping target for latency test") },
                placeholder = { Text("1.1.1.1") },
                modifier = Modifier.fillMaxWidth()
            )

            Button(onClick = {
                scope.launch {
                    settingsRepository.setRouterHost(hostField)
                    settingsRepository.setPingTarget(pingField)
                }
            }) {
                Text("Save")
            }
        }
    }
}

/** Small helper so this file doesn't need an extra lifecycle-runtime-compose import path mismatch. */
@Composable
private fun <T> kotlinx.coroutines.flow.Flow<T>.collectAsStateWithLifecycleCompat(initial: T) =
    this.collectAsState(initial = initial)
