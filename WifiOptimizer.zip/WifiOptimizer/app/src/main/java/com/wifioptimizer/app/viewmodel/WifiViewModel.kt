package com.wifioptimizer.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.wifioptimizer.app.data.NetworkQualityTester
import com.wifioptimizer.app.data.RecommendationEngine
import com.wifioptimizer.app.data.SettingsRepository
import com.wifioptimizer.app.data.WifiMonitor
import com.wifioptimizer.app.data.WifiMonitorRepository
import com.wifioptimizer.app.model.QualitySample
import com.wifioptimizer.app.model.QualityVerdict
import com.wifioptimizer.app.model.ScannedAp
import com.wifioptimizer.app.model.WifiSample
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class WifiUiState(
    val currentSample: WifiSample? = null,
    val quality: QualitySample? = null,
    val nearbyAps: List<ScannedAp> = emptyList(),
    val verdict: QualityVerdict = RecommendationEngine.evaluate(null, null, emptyList(), emptyList()),
    val isRunningQualityTest: Boolean = false,
)

class WifiViewModel(application: Application) : AndroidViewModel(application) {

    private val wifiMonitor = WifiMonitor(application)
    private val qualityTester = NetworkQualityTester()
    val settingsRepository = SettingsRepository(application)

    private val _quality = MutableStateFlow<QualitySample?>(null)
    private val _nearbyAps = MutableStateFlow<List<ScannedAp>>(emptyList())
    private val _isRunningQualityTest = MutableStateFlow(false)

    val uiState: StateFlow<WifiUiState> = combine(
        WifiMonitorRepository.latestSample,
        _quality,
        _nearbyAps,
        WifiMonitorRepository.rssiHistory,
        _isRunningQualityTest,
    ) { sample, quality, aps, history, running ->
        WifiUiState(
            currentSample = sample,
            quality = quality,
            nearbyAps = aps,
            verdict = RecommendationEngine.evaluate(sample, quality, aps, history),
            isRunningQualityTest = running,
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), WifiUiState())

    init {
        // Immediate first read so the UI isn't empty before the foreground service starts polling.
        wifiMonitor.readCurrentSample()?.let { WifiMonitorRepository.pushSample(it) }
        refreshScan()
    }

    fun runQualityTestNow() {
        viewModelScope.launch {
            _isRunningQualityTest.value = true
            val result = qualityTester.runProbe()
            _quality.value = result
            _isRunningQualityTest.value = false
        }
    }

    fun refreshScan() {
        viewModelScope.launch {
            wifiMonitor.startScan()
            // Scans are async at the OS level; give it a moment before reading results.
            kotlinx.coroutines.delay(1500)
            val currentSsid = uiState.value.currentSample?.ssid
            _nearbyAps.value = wifiMonitor.getScanResults(currentSsid)
        }
    }
}
