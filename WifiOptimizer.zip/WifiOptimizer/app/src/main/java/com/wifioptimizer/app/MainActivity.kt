package com.wifioptimizer.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.wifioptimizer.app.data.WifiMonitorService
import com.wifioptimizer.app.ui.DashboardScreen
import com.wifioptimizer.app.ui.SettingsScreen
import com.wifioptimizer.app.ui.theme.WifiOptimizerTheme
import com.wifioptimizer.app.viewmodel.WifiViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: WifiViewModel by viewModels()

    private val requiredPermissions: Array<String>
        get() = buildList {
            add(Manifest.permission.ACCESS_WIFI_STATE)
            add(Manifest.permission.CHANGE_WIFI_STATE)
            add(Manifest.permission.ACCESS_NETWORK_STATE)
            if (Build.VERSION.SDK_INT >= 33) {
                add(Manifest.permission.NEARBY_WIFI_DEVICES)
                add(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                add(Manifest.permission.ACCESS_FINE_LOCATION)
            }
        }.toTypedArray()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        if (results.values.all { it }) {
            startMonitoringService()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            WifiOptimizerTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    var screen by remember { mutableStateOf(Screen.Dashboard) }
                    var permissionsGranted by remember { mutableStateOf(hasAllPermissions()) }

                    if (!permissionsGranted) {
                        PermissionGate(onRequest = {
                            permissionLauncher.launch(requiredPermissions)
                        })
                    } else {
                        when (screen) {
                            Screen.Dashboard -> DashboardScreen(
                                viewModel = viewModel,
                                onOpenSettings = { screen = Screen.Settings }
                            )
                            Screen.Settings -> SettingsScreen(
                                settingsRepository = viewModel.settingsRepository,
                                onBack = { screen = Screen.Dashboard }
                            )
                        }
                    }

                    // Re-check after returning from the system permission dialog.
                    permissionsGranted = hasAllPermissions()
                    if (permissionsGranted) startMonitoringService()
                }
            }
        }
    }

    private fun hasAllPermissions(): Boolean = requiredPermissions.all {
        ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
    }

    private fun startMonitoringService() {
        val intent = Intent(this, WifiMonitorService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private enum class Screen { Dashboard, Settings }
}

@Composable
private fun PermissionGate(onRequest: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "Wi-Fi Optimizer needs Wi-Fi and nearby-device/location permission to read signal " +
                "strength and scan for nearby access points. Android requires this for any app " +
                "that reads Wi-Fi scan results — it's a platform-wide privacy rule, not something " +
                "specific to this app."
        )
        androidx.compose.foundation.layout.Spacer(Modifier.padding(8.dp))
        Button(onClick = onRequest) { Text("Grant permissions") }
    }
}
