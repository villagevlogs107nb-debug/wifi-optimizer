# Add project specific ProGuard rules here.
# Minify is disabled by default for this project (see build.gradle.kts).
